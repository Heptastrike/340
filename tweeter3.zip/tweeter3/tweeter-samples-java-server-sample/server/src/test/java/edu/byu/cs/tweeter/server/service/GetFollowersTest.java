package edu.byu.cs.tweeter.server.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Arrays;

import edu.byu.cs.tweeter.model.domain.AuthToken;
import edu.byu.cs.tweeter.model.domain.User;
import edu.byu.cs.tweeter.model.net.request.FollowersRequest;
import edu.byu.cs.tweeter.model.net.response.FollowersResponse;
import edu.byu.cs.tweeter.server.dao.FollowersDAO;

public class GetFollowersTest {

    private FollowersRequest request;
    private FollowersResponse expectedResponse;
    private FollowersDAO mockFollowersDAO;
    private FollowService followServiceSpy;

    @Before
    public void setup() {
        AuthToken authToken = new AuthToken();

        User currentUser = new User("FirstName", "LastName", null);

        User resultUser1 = new User("FirstName1", "LastName1",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/donald_duck.png");
        User resultUser2 = new User("FirstName2", "LastName2",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/daisy_duck.png");
        User resultUser3 = new User("FirstName3", "LastName3",
                "https://faculty.cs.byu.edu/~jwilkerson/cs340/tweeter/images/daisy_duck.png");

        // Setup a request object to use in the tests
        request = new FollowersRequest(authToken, currentUser.getAlias(), 3, null);

        // Setup a mock FollowersDAO that will return known responses
        expectedResponse = new FollowersResponse(Arrays.asList(resultUser1, resultUser2, resultUser3), false);
        mockFollowersDAO = Mockito.mock(FollowersDAO.class);
        Mockito.when(mockFollowersDAO.getFollowers(request)).thenReturn(expectedResponse);

        followServiceSpy = Mockito.spy(FollowService.class);
        Mockito.when(followServiceSpy.getFollowersDAO()).thenReturn(mockFollowersDAO);
    }

    /**
     * Verify that the {@link FollowService#getFollowers(FollowersRequest)}
     * method returns the same result as the {@link FollowersDAO} class.
     */
    @Test
    public void testGetFollowers_validRequest_correctResponse() {
        FollowersResponse response = followServiceSpy.getFollowers(request);
        Assert.assertEquals(expectedResponse, response);
    }
}
