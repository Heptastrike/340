package edu.byu.cs.tweeter.server.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Arrays;

import edu.byu.cs.tweeter.model.domain.AuthToken;
import edu.byu.cs.tweeter.model.domain.User;
import edu.byu.cs.tweeter.model.net.request.FollowersCountRequest;
import edu.byu.cs.tweeter.model.net.request.FollowersRequest;
import edu.byu.cs.tweeter.model.net.response.FollowersCountResponse;
import edu.byu.cs.tweeter.model.net.response.FollowersResponse;
import edu.byu.cs.tweeter.server.dao.FollowersDAO;

public class GetFollowersCount {

    private FollowersCountRequest request;
    private FollowersCountResponse expectedResponse;
    private FollowService followServiceSpy;

    @Before
    public void setup() {
        AuthToken authToken = new AuthToken();

        User currentUser = new User("FirstName", "LastName", null);

        // Setup a request object to use in the tests
        request = new FollowersCountRequest(authToken, currentUser);

        // Setup a mock FollowersDAO that will return known responses
        expectedResponse = new FollowersCountResponse(5);

        followServiceSpy = Mockito.spy(FollowService.class);
        Mockito.when(followServiceSpy.getFollowersCount(request)).thenReturn(expectedResponse);
    }

    /**
     * Verify that the {@link FollowService#getFollowers(FollowersRequest)}
     * method returns the same result as the {@link FollowersDAO} class.
     */
    @Test
    public void testGetFollowers_validRequest_correctResponse() {
        FollowersCountResponse response = followServiceSpy.getFollowersCount(request);
        Assert.assertEquals(expectedResponse, response);
    }
}
