package edu.byu.cs.tweeter.server.dao;

import java.util.ArrayList;
import java.util.List;

import edu.byu.cs.tweeter.model.domain.Status;
import edu.byu.cs.tweeter.model.domain.User;
import edu.byu.cs.tweeter.model.net.request.FeedRequest;
import edu.byu.cs.tweeter.model.net.response.FeedResponse;
import edu.byu.cs.tweeter.util.FakeData;

public class FeedDAO {
    /**
     * Gets the count of users from the database that the user specified is following. The
     * current implementation uses generated data and doesn't actually access a database.
     *
     * @param user the User whose count of how many following is desired.
     * @return said count.
     */
    public Integer getFeedCount(User user) {
        // TODO: uses the dummy data.  Replace with a real implementation.
        assert user != null;
        return getDummyFeed().size();
    }

    /**
     * Gets the users from the database that the user specified in the request is following. Uses
     * information in the request object to limit the number of followees returned and to return the
     * next set of followees after any that were returned in a previous request. The current
     * implementation returns generated data and doesn't actually access a database.
     *
     * @param request contains information about the user whose followees are to be returned and any
     *                other information required to satisfy the request.
     * @return the followees.
     */
    public FeedResponse getFeed(FeedRequest request) {
        // TODO: Generates dummy data. Replace with a real implementation.
        assert request.getLimit() > 0;
        assert request.getUserAlias() != null;

        List<Status> allPosts = getDummyFeed();
        List<Status> responsePosts = new ArrayList<>(request.getLimit());

        boolean hasMorePages = false;

        if(request.getLimit() > 0) {
            if (allPosts != null) {
                int postsIndex = getPostsStartingIndex(request.getLastFeedStatus(), allPosts);

                for(int limitCounter = 0; postsIndex < allPosts.size() && limitCounter < request.getLimit(); postsIndex++, limitCounter++) {
                    responsePosts.add(allPosts.get(postsIndex));
                }

                hasMorePages = postsIndex < allPosts.size();
            }
        }

        return new FeedResponse(responsePosts, hasMorePages);
    }

    /**
     * Determines the index for the first followee in the specified 'allPosts' list that should
     * be returned in the current request. This will be the index of the next followee after the
     * specified 'lastFollowee'.
     *
     * @param lastStoryStatus the alias of the last followee that was returned in the previous
     *                          request or null if there was no previous request.
     * @param allPosts the generated list of followees from which we are returning paged results.
     * @return the index of the first followee to be returned.
     */
    private int getPostsStartingIndex(Status lastStoryStatus, List<Status> allPosts) {

        int postsIndex = 0;

        if(lastStoryStatus != null) {
            // This is a paged request for something after the first page. Find the first item
            // we should return
            for (int i = 0; i < allPosts.size(); i++) {
                if(lastStoryStatus.equals(allPosts.get(i))) {
                    // We found the index of the last item returned last time. Increment to get
                    // to the first one we should return
                    postsIndex = i + 1;
                    break;
                }
            }
        }

        return postsIndex;
    }

    /**
     * Returns the list of dummy followee data. This is written as a separate method to allow
     * mocking of the followees.
     *
     * @return the followees.
     */
    List<Status> getDummyFeed() {
        return getFakeData().getFakeStatuses();
    }

    /**
     * Returns the {@link FakeData} object used to generate dummy followees.
     * This is written as a separate method to allow mocking of the {@link FakeData}.
     *
     * @return a {@link FakeData} instance.
     */
    FakeData getFakeData() {
        return new FakeData();
    }
}
