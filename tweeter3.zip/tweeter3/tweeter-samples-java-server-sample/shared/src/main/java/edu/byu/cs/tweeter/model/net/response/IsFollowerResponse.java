package edu.byu.cs.tweeter.model.net.response;

public class IsFollowerResponse extends Response {

    public IsFollowerResponse() {
        super(true, null);
    }

    public IsFollowerResponse(String message) {
        super(false, message);
    }
}
