package edu.byu.cs.tweeter.client.model.service.backgroundTask.Observer;

public interface GetUserObserver extends UserObserver {
    void ToastProfile();
}
