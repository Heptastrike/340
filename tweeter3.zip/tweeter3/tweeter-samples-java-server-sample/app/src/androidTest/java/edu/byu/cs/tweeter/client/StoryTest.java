package edu.byu.cs.tweeter.client;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.List;
import java.util.concurrent.CountDownLatch;

import edu.byu.cs.tweeter.client.model.service.StatusService;
import edu.byu.cs.tweeter.client.model.service.backgroundTask.Observer.PagedObserver;
import edu.byu.cs.tweeter.client.presenter.StatusPresenter.GetStatusObserver;
import edu.byu.cs.tweeter.model.domain.AuthToken;
import edu.byu.cs.tweeter.model.domain.Status;
import edu.byu.cs.tweeter.model.domain.User;
import edu.byu.cs.tweeter.model.net.request.StoryRequest;
import edu.byu.cs.tweeter.util.FakeData;


public class StoryTest {


    private StatusService statusServiceSpy;
    public StoryObserver mockObserver;
    private CountDownLatch countDownLatch;

    AuthToken authToken;
    User user;
    int pageSize;
    Status lastStatus;
    FakeData fake = new FakeData();

    private void resetCountDownLatch() {
        countDownLatch = new CountDownLatch(1);
    }

    private void awaitCountDownLatch() throws InterruptedException {
        countDownLatch.await();
        resetCountDownLatch();
    }

    private class StoryObserver implements PagedObserver<Status> {

        private List<Status> items;
        private boolean hasMorePages;

        public List<Status> getItems() {
            return items;
        }

        public boolean getPages() {
            return hasMorePages;
        }


        @Override
        public void handleSuccess(List<Status> items, boolean hasMorePages) {
            this.items = fake.getFakeStatuses();
            this.hasMorePages = hasMorePages;
            countDownLatch.countDown();
        }

        @Override
        public void handleFailure(String message) {

        }

        @Override
        public void handleException(Exception ex) {

        }
    }

    @Before
    public void setup() {
        fake.generateFakeStatuses();
        authToken = new AuthToken();
        user = new FakeData().getFirstUser();
        pageSize = 10;
        lastStatus = null;
        mockObserver = new StoryObserver();
        statusServiceSpy = Mockito.spy(StatusService.class);
        resetCountDownLatch();
    }

    @Test
    public void testGetFollowees_validRequest_correctResponse() throws InterruptedException {

        statusServiceSpy.getStory(authToken, user, pageSize, lastStatus, mockObserver);
        awaitCountDownLatch();
        Assert.assertEquals(true, mockObserver.getPages());
        Assert.assertEquals(fake.getFakeStatuses(), mockObserver.getItems());

    }
}

